import java.util.*;
class Q3{
	public static void main(String[] s){
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		System.out.println(str.length());
		sc.close();
	}	
}

