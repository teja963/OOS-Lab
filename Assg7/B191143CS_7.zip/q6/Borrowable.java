import java.lang.*;
import java.util.*;

interface Borrowable{
	  public void checkIn();
	  public void checkOut();
}
