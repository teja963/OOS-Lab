import java.lang.*;
import java.util.*;

interface TaxCalculatable{
	  public double getTax();
}
